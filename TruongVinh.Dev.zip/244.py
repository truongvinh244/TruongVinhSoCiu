import subprocess # Truy Cập File
import time # Thời Gian
import random # Quay Ngẫu Nhiên
from colorama import Fore, Style # Màu Cho Chữ
import os # Phần Miềm
# Fore.BLUE // Xanh Nước Biển Đậm
# Fore.CYAN // Xanh Nước Biển Nhạt
# Fore.MAGENTA // Màu Tím
# Fore.YELLOW // Vàng
# Fore.RED // Đỏ
# Fore.GREEN // Xanh Lá
# Style.BRIGHT // In Đậm
q1,q2,q3,q4,q5 = Fore.RED,Fore.YELLOW,Style.RESET_ALL,Fore.CYAN,Style.BRIGHT # Màu Và Style -- Model

def spt():
    subprocess.call(['python', 'MXH/sptf.py'])
def yt():
    subprocess.call(['python', 'MXH/youtube.py'])
def tt():
    subprocess.call(['python', 'MXH/tiktok.py'])
def fb():
    subprocess.call(['python', 'MXH/face.py'])
    
while True:
    if __name__ == "__main__":
        print("\n")
        print(f"{q4+q5} 1 = Youtube")
        print(" 2 = TikTok")
        print(" 3 = FaceBook")
        print(f" 4 = Spotify{q3}")
        open = int(input("Nhập thứ bạn cần mở: ")) # Nhấn 113 để out vòng lặp
        print("Đã nhận, vui lòng đợi...")
        time.sleep(1)
        os.system('clear') #clear = linux -- cls = windows
        ## os..... đó là 1 công cụ giúp xóa chữ khi chạy, dọn sạch cmd ok:))))
        h = random.randint(1,4)
        if open == 1:
            yt()
        elif open == 2:
            tt()
        elif open == 3:
            fb()
        elif open == 4:
            spt()
        elif open == 113:
            break
        else:
            subprocess.call(['python', 'MXH/troll.py'])

## Made By TruongVinh
## File Này Mục Đích Về Phần Miềm Và Mở Phần Miềm, Phục Vụ Cho Các Công Việc Sau Này
