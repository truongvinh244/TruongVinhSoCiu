import subprocess
def open_browser(url):
  subprocess.call(["termux-open", url])
open_browser("https://facebook.com/")
# Mở Phây Bút