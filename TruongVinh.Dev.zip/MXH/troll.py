import subprocess
# idk hehe























def open_browser(url):
  subprocess.call(["termux-open", url])



















open_browser("https://youtu.be/dQw4w9WgXcQ?si=etO3gyc2pKbc97QR")